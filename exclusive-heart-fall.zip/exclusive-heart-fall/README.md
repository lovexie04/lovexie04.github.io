# (EXCLUSIVE) Heart Fall

A Pen created on CodePen.

Original URL: [https://codepen.io/Pedro-Inacio/pen/wBKvzWW](https://codepen.io/Pedro-Inacio/pen/wBKvzWW).

* First: This is lag? 🤔
If you want to know this, i say it not so much lag, this pen use requestAnimationFrame(function) to call function every frame based on user FPS
* Second: What is this pen? 🤔
This pen is a realistic Heart Fall it fall particles and fire particles!
* Third: You i can edit this? 🤔
You can edit font-size of .container to make it smaller/larger,  animations and particles

* End!
Thanks for supporting me! Good bye!